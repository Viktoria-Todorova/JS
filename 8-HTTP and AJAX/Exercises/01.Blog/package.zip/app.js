const loadBtnEl = document.querySelector('#btnLoadPosts');
const postselectEl = document.querySelector('#posts');
const vieBtnEl = document.querySelector('#btnViewPost');
const titleH1El = document.querySelector('#post-title');
const BodyEl = document.querySelector('#post-body');
const commentUlEl = document.querySelector('#post-comments');


function attachEvents() {
    loadBtnEl.addEventListener('click', handleLoadPost);
    vieBtnEl.addEventListener('click',handleDisplayPost);

    async function handleLoadPost(){
        const postRes =await fetch('http://localhost:3030/jsonstore/blog/posts');
        const postData = await postRes.json();
        const postArr = Object.values(postData);

        postArr.forEach(postob => {
            const optionalEl = document.createElement('option');
            optionalEl.value = postob.id;
            optionalEl.textContent= postob.title ;

            postselectEl.appendChild(optionalEl);
        })
        

    }

    async function handleDisplayPost(){
        const selectPostId = postselectEl.value;

        const postRes =await fetch('http://localhost:3030/jsonstore/blog/posts');
        const postData = await postRes.json();

        const postArr = Object.values(postData);
        const selectedPostObj = postArr.find(p => p.id === selectPostId);
        titleH1El.textContent =selectedPostObj.title;
        BodyEl.textContent =selectedPostObj.body;
        
        
    }
}

attachEvents();

//http://localhost:3030/jsonstore/blog/comments