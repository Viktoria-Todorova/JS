function solve() {
    const infoSpan = document.querySelector('#info .info');
    const departBtn = document.getElementById('depart');
    const arriveBtn = document.getElementById('arrive');

    let currentStop = {
        name: '',
        next: 'depot'
    };

    async function depart() {
        try {
            const response = await fetch(`http://localhost:3030/jsonstore/bus/schedule/${currentStop.next}`);

            if (!response.ok) {
                throw new Error('Fetch failed');
            }

            const data = await response.json();

            currentStop.name = data.name;
            currentStop.next = data.next;

            infoSpan.textContent = `Next stop ${currentStop.name}`;
            departBtn.disabled = true;
            arriveBtn.disabled = false;
        } catch (error) {
            showError();
        }
    }

    function arrive() {
        infoSpan.textContent = `Arriving at ${currentStop.name}`;
        departBtn.disabled = false;
        arriveBtn.disabled = true;
    }

    function showError() {
        infoSpan.textContent = 'Error';
        departBtn.disabled = true;
        arriveBtn.disabled = true;
    }

    return {
        depart,
        arrive
    };
}

const result = solve();
